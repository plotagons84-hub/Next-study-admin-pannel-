# Next Study Admin Panel

A separate, standalone web app whose only job is controlling the **Next Study** public site remotely. Deploy this to its own URL (different from the public site) - it's the same black & orange liquid-glass style, React + TanStack Router + Tailwind + Firebase, but there is no public-facing content here at all: opening the URL takes you straight into the admin flow.

`robots: noindex, nofollow` is set in `index.html` so it doesn't show up in search results - it's not linked from the public site either. Treat the URL itself as semi-private, and definitely don't publish it anywhere public. The Firebase Auth login is the real gate, but there's no reason to advertise the address.

## The flow

**Splash** ("Enter System") → **Login / Register** (name + password) → **Access Granted** (brief animated transition) → **Panel** with 6 tabs: **Stats, Control, Links, Buttons, Announce, AI Chat**. Voice plays throughout via the browser's built-in Web Speech API (free, no key) - a greeting on login, "Access granted, welcome back", and the AI Tutor speaks every answer.

### Logging in — Name + Password, backed by Firebase

Firebase Auth's email/password sign-in needs an email, but the login screen only asks for a name. Each name is turned into a throwaway address like `zishan.ahmad@admin.nextstudy.local` purely so Firebase has something to key the account on - nothing is ever sent there.

**First time**: tap **"First time here? Create an admin account"**, enter `ZISHAN AHMAD` / `ZISHANAHMAD2009`, submit - that creates the real Firebase account. From then on, log in with the same name + password. Repeat for any other admin; everyone who's ever logged in shows up in **Control → Admins**, by name only.

### The 6 tabs

- **Stats** — real Firestore numbers: total opens, online now (approximate presence heartbeat), how many top-level cards are locked, admin count. System Health reflects Maintenance Mode.
- **Control** — Maintenance Mode / Telegram-popup / urgent-alert on-off switches, and the Admins list.
- **Links** — lock/unlock any of the 4 top-level cards on the public site, and edit any PW/Next Topper sub-platform's destination URL. This is the "lock it so no one else can open it" feature - takes effect on the live site within seconds.
- **Buttons** — edit where the Telegram-popup button and the urgent-alert banner actually point.
- **Announce** — write the banner shown on the public site's home page: text, a color (red/orange/green), on/off.
- **AI Chat** — demo NEET/JEE knowledge base (`src/lib/aiTutor.js`), speaks its answers, has a mic button for spoken questions. For genuinely intelligent answers, that file has a documented spot for a real AI API call - needs a small backend, since browsers can't safely hold a secret API key or call most AI providers directly.

## Firebase setup (shared with the public site — one Firebase project, two apps)

This project and the public **Next Study** site both point at the same Firebase project (`next-study-admin-pannel`, config already in `src/lib/firebase.js`) - that's the entire "how do I link them" answer: no separate linking step, they just both read/write the same Firestore database.

In the [Firebase console](https://console.firebase.google.com/):

1. **Authentication → Sign-in method** → confirm **Email/Password** is enabled.
2. **Firestore Database** → **Create database** if you haven't already (production mode is fine).
3. **Firestore Database → Rules** → paste in `firestore.rules` (included in this project) and **Publish**:
   - `config/*` (platform locks, announcement, toggles) — anyone can read, only a signed-in admin can write.
   - `stats/*` (opens counter) — anyone can bump it, only an admin can delete it.
   - `presence/*` (online-now heartbeats) — open, since visitors aren't signed in.
   - `admins/*` — only signed-in admins can read the list; each admin can only write their own record.

### Two honest caveats

- **"Online now" is approximate** — each open tab on the public site pings every 20s; the count is "pings in the last 60 seconds," with no server-side cleanup of stale sessions.
- **The opens counter and presence writes are open to any visitor**, by design - a public-site visitor isn't logged in, so there's no other way for their browser to bump a counter. Fine for a display metric; if abuse ever becomes a real concern, the fix is a Cloud Function instead of a direct client write - a backend change, not something these rules alone prevent.

## Running it

```bash
npm install
npm run dev
```

Runs on port 5174 by default (the public site's `npm run dev` uses 5173), so you can run both side by side. `npm run build` produces a production build in `dist/` - deploy that to its own hosting (e.g. a separate Netlify/Vercel project) so it has its own URL, separate from the public site.
