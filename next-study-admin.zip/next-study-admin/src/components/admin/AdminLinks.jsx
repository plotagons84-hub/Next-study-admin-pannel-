import { useEffect, useState } from 'react'
import { Lock, Unlock, Save } from 'lucide-react'
import { platforms as basePlatforms } from '../../data/constants'
import { subscribePlatforms, setPlatformOverride } from '../../lib/platformsFirestore'

function ToggleRow({ item, baseKind }) {
  const locked = item.kind === 'locked'
  return (
    <div className="flex items-center justify-between gap-3 py-3">
      <div className="min-w-0">
        <p className="text-sm font-medium text-white truncate">{item.name}</p>
        <p className="text-xs text-white/40 truncate">
          {item.kind === 'link' ? item.href : item.kind === 'dashboard' ? `internal \u2192 ${item.to}` : 'locked'}
        </p>
      </div>
      <button
        onClick={() => setPlatformOverride(item.id, { kind: locked ? baseKind : 'locked' })}
        className={`shrink-0 flex items-center gap-1.5 text-xs font-medium rounded-full px-3 py-1.5 transition-colors ${
          locked ? 'bg-white/5 text-white/50 hover:bg-white/10' : 'bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20'
        }`}
      >
        {locked ? <Lock size={13} /> : <Unlock size={13} />}
        {locked ? 'Locked' : 'Live'}
      </button>
    </div>
  )
}

function UrlEditRow({ item }) {
  const [value, setValue] = useState(item.url)
  const [saved, setSaved] = useState(false)

  return (
    <div className="py-3">
      <p className="text-sm font-medium text-white">{item.name}</p>
      <div className="flex items-center gap-2 mt-1.5">
        <input
          value={value}
          onChange={(e) => {
            setValue(e.target.value)
            setSaved(false)
          }}
          className="flex-1 min-w-0 glass-pill rounded-full px-4 py-2 text-xs text-white/80 outline-none font-mono"
        />
        <button
          onClick={() => {
            setPlatformOverride(item.id, { url: value })
            setSaved(true)
          }}
          className="shrink-0 h-8 w-8 grid place-items-center rounded-full bg-orange-500/15 text-orange-400 hover:bg-orange-500/25 transition-colors"
          aria-label="Save"
        >
          <Save size={14} />
        </button>
      </div>
      {saved && <p className="text-[11px] text-emerald-400 mt-1">Saved &mdash; live for every visitor now.</p>}
    </div>
  )
}

export default function AdminLinks() {
  const [top, setTop] = useState(basePlatforms)
  const [pw, setPw] = useState([])
  const [nt, setNt] = useState([])

  useEffect(
    () =>
      subscribePlatforms((data) => {
        setTop(data.platforms)
        setPw(data.pwPlatforms)
        setNt(data.nextTopperPlatforms)
      }),
    []
  )

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">Links</h1>
        <p className="text-sm text-white/50 mt-1">Lock any card, or edit a link &mdash; live for every visitor.</p>
      </div>

      <div className="glass rounded-xl2 p-5">
        <h2 className="font-display font-semibold text-white mb-1">Top-level cards</h2>
        <div className="divide-y divide-white/10">
          {top.map((item) => (
            <ToggleRow key={item.id} item={item} baseKind={basePlatforms.find((b) => b.id === item.id)?.kind} />
          ))}
        </div>
      </div>

      <div className="glass rounded-xl2 p-5">
        <h2 className="font-display font-semibold text-white mb-1">PW Ultimate links</h2>
        <div className="divide-y divide-white/10">
          {pw.map((item) => (
            <UrlEditRow key={item.id} item={item} />
          ))}
        </div>
      </div>

      <div className="glass rounded-xl2 p-5">
        <h2 className="font-display font-semibold text-white mb-1">Next Topper Ultimate links</h2>
        <div className="divide-y divide-white/10">
          {nt.map((item) => (
            <UrlEditRow key={item.id} item={item} />
          ))}
        </div>
      </div>
    </div>
  )
}
