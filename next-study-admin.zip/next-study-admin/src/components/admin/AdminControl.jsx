import { useEffect, useState } from 'react'
import { AlertOctagon, Send, Siren, Users } from 'lucide-react'
import { subscribeAppControl, setAppControl } from '../../lib/platformsFirestore'
import { subscribeAdminsList } from '../../lib/adminAuth'

function ToggleCard({ icon: Icon, title, description, checked, onChange, danger }) {
  return (
    <div className="glass rounded-xl2 p-4 sm:p-5 flex items-start gap-4">
      <div
        className={`h-10 w-10 shrink-0 rounded-full grid place-items-center border ${
          danger ? 'bg-red-500/10 border-red-500/30 text-red-400' : 'bg-orange-500/10 border-orange-500/30 text-orange-400'
        }`}
      >
        <Icon size={17} />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold text-white">{title}</p>
        <p className="text-xs text-white/50 mt-0.5">{description}</p>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={`shrink-0 relative h-7 w-12 rounded-full transition-colors ${
          checked ? (danger ? 'bg-red-500' : 'bg-orange-500') : 'bg-white/10'
        }`}
        aria-pressed={checked}
      >
        <span
          className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-transform ${
            checked ? 'translate-x-6' : 'translate-x-1'
          }`}
        />
      </button>
    </div>
  )
}

export default function AdminControl() {
  const [control, setControl] = useState({
    maintenanceMode: false,
    telegramPopupEnabled: true,
    urgentAlertEnabled: true,
  })
  const [admins, setAdmins] = useState([])

  useEffect(() => {
    const unsub1 = subscribeAppControl(setControl)
    const unsub2 = subscribeAdminsList(setAdmins)
    return () => {
      unsub1()
      unsub2()
    }
  }, [])

  function update(patch) {
    setControl((c) => ({ ...c, ...patch }))
    setAppControl(patch)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">Control</h1>
        <p className="text-sm text-white/50 mt-1">App-wide switches &mdash; changes apply to every visitor.</p>
      </div>

      <div className="space-y-3">
        <ToggleCard
          icon={AlertOctagon}
          title="Maintenance Mode"
          description="Marks the system health as degraded on the Stats tab"
          checked={control.maintenanceMode}
          onChange={(v) => update({ maintenanceMode: v })}
          danger
        />
        <ToggleCard
          icon={Send}
          title="Telegram Popup"
          description="Show the join-Telegram popup when the app opens"
          checked={control.telegramPopupEnabled}
          onChange={(v) => update({ telegramPopupEnabled: v })}
        />
        <ToggleCard
          icon={Siren}
          title="Urgent Alert Banner"
          description="Show the red urgent-alert banner on the home page"
          checked={control.urgentAlertEnabled}
          onChange={(v) => update({ urgentAlertEnabled: v })}
        />
      </div>

      <div className="glass rounded-xl2 p-5">
        <h2 className="font-display font-semibold text-white flex items-center gap-2">
          <Users size={17} className="text-orange-400" />
          Admins ({admins.length})
        </h2>
        <div className="mt-3 divide-y divide-white/10">
          {admins.length === 0 && <p className="text-sm text-white/40 py-2">No admins yet.</p>}
          {admins.map((a) => (
            <div key={a.id} className="flex items-center justify-between py-2.5 text-sm">
              <span className="text-white/80">{a.name}</span>
              <span className="text-[11px] text-white/35 font-mono">
                {a.lastLogin?.toDate ? a.lastLogin.toDate().toLocaleString() : '\u2014'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
